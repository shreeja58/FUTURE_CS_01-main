#!/bin/bash
# Nmap Commands for Vulnerability Assessment
# Note: Scans performed on scanme.nmap.org (safe testing domain)

# Basic Port Scan
# Shows open ports and basic service detection
nmap -sS -sV scanme.nmap.org

# Service and Version Detection
# Identifies service versions for vulnerability matching
nmap -sV scanme.nmap.org

# Operating System Detection
# Determines target OS for OS-specific vulnerabilities
nmap -O scanme.nmap.org

# Comprehensive Scan
# Full service/version/OS detection with timing
nmap -sS -sV -O -A scanme.nmap.org

# Specific Port Scan
# Scan specific ports: SSH (22), HTTP (80), HTTPS (443)
nmap -p 22,80,443 -sV scanme.nmap.org

# SSH Banner Grabbing
# Connect to SSH and retrieve version information
ssh -v scanme.nmap.org

# Output to File
# Save results for documentation
nmap -sS -sV -O -A -oN nmap_results.txt scanme.nmap.org
nmap -sS -sV -O -A -oX nmap_results.xml scanme.nmap.org

# Common Ports Only
nmap -p 1-1024 -sV scanme.nmap.org

# Verbose Output
nmap -sS -sV -v scanme.nmap.org

# Timing Options (for network optimization)
# T0: Paranoid, T5: Insane
nmap -sS -sV -T3 scanme.nmap.org

# Script-based Scanning (NSE)
# Use Nmap Scripting Engine for advanced checks
nmap --script default,banner scanme.nmap.org
nmap --script ssl-cert scanme.nmap.org:443

# Notes:
# - All scans performed on scanme.nmap.org per ethical guidelines
# - SYN scan (-sS) used for accuracy
# - Service version detection (-sV) for vulnerability matching
# - Consider network impact before running comprehensive scans
# - Requires appropriate permissions and authorization
