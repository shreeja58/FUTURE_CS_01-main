# Remediation Recommendations

## Overview
This document provides actionable remediation recommendations for all identified vulnerabilities.

---

## Recommendation #1: Implement Content Security Policy (CSP)

### Priority: High
### Effort: Medium
### Impact: Blocks XSS attacks

### Implementation Steps

**For Apache (.htaccess):**
```apache
Header set Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'"
```

**For Nginx:**
```nginx
add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'" always;
```

**For Node.js/Express:**
```javascript
app.use((req, res, next) => {
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'");
  next();
});
```

### Verification
- Use browser DevTools to verify CSP header presence
- Test with OWASP ZAP passive scanner

---

## Recommendation #2: Add X-Frame-Options Header

### Priority: High
### Effort: Low
### Impact: Prevents clickjacking attacks

### Implementation Steps

**For Apache (.htaccess):**
```apache
Header always set X-Frame-Options "DENY"
```

**For Nginx:**
```nginx
add_header X-Frame-Options "DENY" always;
```

**For Node.js/Express:**
```javascript
app.use((req, res, next) => {
  res.setHeader('X-Frame-Options', 'DENY');
  next();
});
```

### Options Explained
- `DENY` - Never allow framing
- `SAMEORIGIN` - Allow framing from same origin
- `ALLOW-FROM uri` - Deprecated (use CSP frame-ancestors instead)

---

## Recommendation #3: Add X-Content-Type-Options Header

### Priority: Medium
### Effort: Low
### Impact: Prevents MIME type sniffing

### Implementation Steps

**For Apache (.htaccess):**
```apache
Header always set X-Content-Type-Options "nosniff"
```

**For Nginx:**
```nginx
add_header X-Content-Type-Options "nosniff" always;
```

**For Node.js/Express:**
```javascript
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  next();
});
```

---

## Recommendation #4: Secure Cookie Attributes

### Priority: High
### Effort: Medium
### Impact: Protects session cookies

### Implementation Steps

**For Apache/PHP:**
```php
ini_set('session.cookie_secure', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Strict');
```

**For Node.js/Express:**
```javascript
app.use(session({
  cookie: {
    secure: true,      // HTTPS only
    httpOnly: true,    // No JavaScript access
    sameSite: 'strict' // CSRF protection
  }
}));
```

**For Java (Servlet):**
```xml
<session-config>
  <cookie>
    <secure>true</secure>
    <http-only>true</http-only>
    <same-site>strict</same-site>
  </cookie>
</session-config>
```

### Configuration Details
- **Secure:** Only send cookies over HTTPS
- **HttpOnly:** Prevent JavaScript access (XSS mitigation)
- **SameSite:** Prevent CSRF attacks (Strict/Lax/None)

---

## Recommendation #5: Remove Server Version Information

### Priority: Medium
### Effort: Low
### Impact: Reduces reconnaissance surface

### Implementation Steps

**For Apache:**
```apache
# In apache2.conf or httpd.conf
ServerTokens Prod
ServerSignature Off
```

**For Nginx:**
```nginx
server_tokens off;
```

**For IIS:**
Remove via registry or web.config:
```xml
<security>
  <requestFiltering removeServerHeader="true" />
</security>
```

---

## Recommendation #6: Restrict Port Access

### Priority: Medium
### Effort: Medium
### Impact: Reduces attack surface

### Implementation Steps

**For SSH (Port 22):**
```bash
# Edit /etc/ssh/sshd_config
PermitRootLogin no
PasswordAuthentication no
AllowUsers authorized_user@specific_ip
```

**Using Firewall (Windows):**
```powershell
New-NetFirewallRule -DisplayName "SSH Access" `
  -Direction Inbound -Action Allow -Protocol TCP `
  -LocalPort 22 -RemoteAddress authorized_ip
```

**Using Firewall (Linux):**
```bash
sudo ufw allow from 192.168.1.0/24 to any port 22
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
```

---

## Implementation Priority Matrix

| Priority | Findings | Timeline |
|----------|----------|----------|
| **Critical** | CSP, X-Frame-Options, Cookie Security | Immediate (1-2 days) |
| **High** | X-Content-Type-Options, Server Version | Week 1 |
| **Medium** | Port Restrictions, SSH Hardening | Week 2 |

---

## Testing & Verification Checklist

- [ ] CSP header present in all responses
- [ ] X-Frame-Options header present
- [ ] X-Content-Type-Options header present
- [ ] Cookies have Secure, HttpOnly, SameSite attributes
- [ ] Server version information hidden
- [ ] SSH restricted to authorized IPs
- [ ] Re-scan with OWASP ZAP confirms fixes
- [ ] No high-severity findings remain

---

## Resources & References

- [OWASP Security Headers](https://owasp.org/www-project-secure-headers/)
- [MDN Web Security](https://developer.mozilla.org/en-US/docs/Web/Security)
- [CWE-693: Protection Mechanism Failure](https://cwe.mitre.org/data/definitions/693.html)
- [NIST Cybersecurity Framework](https://www.nist.gov/cyberframework)

---

*Report Generated: April 26, 2026*
*Last Updated: April 26, 2026*
