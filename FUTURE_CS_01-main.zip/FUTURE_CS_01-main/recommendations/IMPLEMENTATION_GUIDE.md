# Implementation Guide - Step by Step

## Quick Implementation Checklist

### Phase 1: Security Headers (1-2 hours)

**For Apache (.htaccess):**
```apache
# Add to your .htaccess file
Header always set Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'"
Header always set X-Frame-Options "DENY"
Header always set X-Content-Type-Options "nosniff"
Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains"
Header always set X-XSS-Protection "1; mode=block"
Header always unset Server
Header always unset X-Powered-By
ServerTokens Prod
ServerSignature Off
```

**For Nginx (nginx.conf):**
```nginx
server {
    # Add to server block
    add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'" always;
    add_header X-Frame-Options "DENY" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-XSS-Protection "1; mode=block" always;
    
    server_tokens off;
}
```

**For Node.js/Express:**
```javascript
const express = require('express');
const app = express();

app.use((req, res, next) => {
    res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'");
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.removeHeader('X-Powered-By');
    next();
});

app.listen(3000);
```

---

### Phase 2: Cookie Security (30-60 minutes)

**For PHP:**
```php
<?php
// Set cookie parameters for all sessions
ini_set('session.cookie_secure', 1);        // HTTPS only
ini_set('session.cookie_httponly', 1);      // No JavaScript access
ini_set('session.cookie_samesite', 'Strict'); // CSRF protection
ini_set('session.cookie_lifetime', 3600);   // 1 hour expiry

session_start();
?>
```

**For Node.js/Express with session:**
```javascript
const session = require('express-session');

app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: true,
    cookie: {
        secure: true,      // HTTPS only
        httpOnly: true,    // No JavaScript access
        sameSite: 'strict', // CSRF protection
        maxAge: 3600000    // 1 hour
    }
}));
```

**For Java (web.xml):**
```xml
<session-config>
    <cookie-config>
        <secure>true</secure>
        <http-only>true</http-only>
    </cookie-config>
    <tracking-mode>COOKIE</tracking-mode>
</session-config>
```

---

### Phase 3: SSH Hardening (1-2 hours)

**Edit /etc/ssh/sshd_config:**
```bash
# Disable root login
PermitRootLogin no

# Use key-based authentication only
PasswordAuthentication no
PubkeyAuthentication yes

# Restrict users
AllowUsers authorized_user@192.168.1.100 another_user@10.0.0.0/8

# Update SSH key exchange algorithms
KexAlgorithms curve25519-sha256,diffie-hellman-group-exchange-sha256

# Upgrade ciphers
Ciphers aes256-ctr,aes192-ctr,aes128-ctr

# Change default port (optional)
Port 2222

# After editing, restart:
sudo systemctl restart sshd
```

**For Windows Firewall (PowerShell - Admin):**
```powershell
# Allow SSH only from specific IP
New-NetFirewallRule -DisplayName "SSH Access" `
  -Direction Inbound -Action Allow -Protocol TCP `
  -LocalPort 22 -RemoteAddress 192.168.1.100

# View existing SSH rules
Get-NetFirewallRule -DisplayName "*SSH*"
```

**For Linux Firewall (UFW):**
```bash
# Allow SSH only from specific IP
sudo ufw allow from 192.168.1.0/24 to any port 22

# View rules
sudo ufw status numbered
```

---

### Phase 4: Software Updates (2-3 hours)

**Update OpenSSH (CRITICAL):**
```bash
# Ubuntu/Debian
sudo apt update
sudo apt upgrade openssh-server

# Verify version
ssh -V

# Should show 8.x or 9.x
```

**Update Apache (IMPORTANT):**
```bash
# Ubuntu/Debian
sudo apt update
sudo apt upgrade apache2

# Verify version
apache2ctl -v

# Should show 2.4.50+
```

**Update system packages:**
```bash
# Full system update
sudo apt update && sudo apt upgrade -y

# Check for security updates
sudo apt install unattended-upgrades
sudo systemctl enable unattended-upgrades
```

---

## Verification Steps

### Verify Security Headers
```bash
# Using curl
curl -I http://demo.testfire.net

# Check for headers:
# ✓ Content-Security-Policy
# ✓ X-Frame-Options
# ✓ X-Content-Type-Options
# ✓ Strict-Transport-Security
# ✗ Server (should not show version)
# ✗ X-Powered-By (should be removed)
```

### Verify Cookies
```bash
# Open DevTools → Application → Cookies
# Check each cookie:
# ✓ Secure flag (🔒)
# ✓ HttpOnly flag (shown in Details)
# ✓ SameSite attribute (Strict)
```

### Verify SSH Update
```bash
ssh -V
# Should show: OpenSSH_8.9 or higher
```

### Re-scan with Nmap
```bash
nmap -sV scanme.nmap.org
# Port 22 should show: OpenSSH 8.9+
```

### Re-scan with OWASP ZAP
```
1. Start fresh OWASP ZAP scan
2. Review Alerts tab
3. Should see ZERO high-severity alerts
4. Export report
```

---

## Implementation Timeline

| Task | Duration | Priority | Status |
|------|----------|----------|--------|
| Add security headers | 1-2 hrs | CRITICAL | ⏳ Pending |
| Configure cookies | 30-60 min | CRITICAL | ⏳ Pending |
| Update OpenSSH | 30 min | CRITICAL | ⏳ Pending |
| SSH hardening | 1-2 hrs | HIGH | ⏳ Pending |
| Update Apache | 30 min | HIGH | ⏳ Pending |
| Firewall rules | 30 min | HIGH | ⏳ Pending |
| Final verification | 1-2 hrs | MEDIUM | ⏳ Pending |

**Total Time: 5-9 hours**

---

## Testing Locally Before Production

### Setup Test Environment
```bash
# Use Docker or VM
docker run -it ubuntu:latest bash

# Or use a test server
```

### Verify Headers
```bash
# After implementation
curl -I http://localhost

# Expected output:
# HTTP/1.1 200 OK
# Content-Security-Policy: default-src 'self'...
# X-Frame-Options: DENY
# X-Content-Type-Options: nosniff
# Strict-Transport-Security: max-age=31536000...
```

### Verify No Security Issues
```bash
# Run ZAP scan on test server
# Run Nmap on test server
# Verify all issues resolved
```

---

## Rollback Plan

If something breaks:

```bash
# Backup before changes
sudo cp /etc/apache2/apache2.conf /etc/apache2/apache2.conf.backup
sudo cp /etc/ssh/sshd_config /etc/ssh/sshd_config.backup

# Restore if needed
sudo cp /etc/apache2/apache2.conf.backup /etc/apache2/apache2.conf
sudo systemctl restart apache2
```

---

## Support Resources

- **Apache Security:** https://httpd.apache.org/docs/current/misc/security_tips.html
- **Nginx Security:** https://nginx.org/en/docs/http/configuring_https_servers.html
- **OpenSSH:** https://www.openssh.com/
- **OWASP Security Headers:** https://owasp.org/www-project-secure-headers/
- **Mozilla SSL Config:** https://ssl-config.mozilla.org/

---

*Implementation Guide*  
*April 26, 2026*
